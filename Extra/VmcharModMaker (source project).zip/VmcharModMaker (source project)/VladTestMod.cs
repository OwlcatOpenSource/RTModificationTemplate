﻿using UnityModManagerNet;
using UnityEngine;

namespace VmcharModMaker
{
    public class VladTestMod
    {
        // Send a response to the mod manager about the launch status, success or not.
        static bool Load(UnityModManager.ModEntry modEntry)
        {
            Debug.LogError("Hello from ModMaker mod!");
            return true; // If false the mod will show an error.
        }
    }
}